import cgi
import datetime
import urllib
import wsgiref.handlers

from google.appengine.ext import db
from google.appengine.api import users
from google.appengine.ext import webapp
from google.appengine.ext.webapp.util import run_wsgi_app

class Tally(db.Model):
  TallyClassName = db.StringProperty()		# eg. houseprice
  RegionSeriesName = db.StringProperty()
  RegionType = db.StringProperty()
  RegionNameSource = db.StringProperty()
  SourceType = db.StringProperty()
  IxName = db.StringProperty()
  SupplementaryData = db.StringProperty()	# eg. avg house value

class TallyDataPoint(db.Model):
  Tally_ID = db.ReferenceProperty(Tally)
  Date = db.DateProperty()
  IxVal = db.FloatProperty()
  SupplementaryData = db.StringProperty()

class PlaceMap(db.Model):
  Name = db.StringProperty()
  Location = db.GeoPtProperty()
  RegionSeriesName = db.StringProperty()
  RegionNameSource = db.StringProperty()
  ParentPlaceName = db.StringProperty()


class GetTally(webapp.RequestHandler):
  def get(self):

    #first log the user interaction
    ui = UserInteraction()
    ui.User = self.request...
    ui.Time = 
    ui.URL = 

    
    #look up city in PlaceMap table names
    cityPMs = PlaceMap.all().filter(Name=city)

    #select from returned records vs provided lat/long, state and country
    #if in doubt, return all and let the client side remove excess

    #ignore for v1, Oz only
    if len(cityPMs) == 0 
      self.response.out.write('Error!')
      ui.Response = 'Error'
      ui.put()
      return

    #collect PlaceMap(s) from city (may be multiple)
    placeMaps = ()
    placeMaps.append(cityPMs)

    #look up state for first city (assume that step above aligned them all to be same)
    statePMs = PlaceMap.all().filter(Name=cityPMs[0].ParentPlaceName)

    #collect PlaceMap(s) from state (may be multiple)
    placeMaps.append(statePMs)

    #look up country for first state
    ctryPMs = PlaceMap.all().filter(Name=statePMs[0].ParentPlaceName)

    #collect PlaceMap(s) from country (may be multiple)
    placeMaps.append(ctryPMs)


    #need to calc av house price... data should be in cities only
    avHousePrices = ()

    #for each PlaceMap, look up Tally
    self.response.out.write(
    for placeMap in placeMaps:
      tallies = Tally.all().filter('RegionSeriesName =', placeMap.RegionSeriesName) \
                         .filter('RegionNameSource =', placeMap.RegionNameSoure) \
                         .filter('TallyClassName =', ****)

      avHousePrices.append( **** parse out of Supp data *****)

      #should be only one, so
      tally = tallies[0]

      #for each Tally, build XML header and indices
      self.response.out.write('<Index blah blah') % (tally.IxName, tally.RegionType, tally.SourceType))
      for dp in TallyDataPoint.all().ancestor(tally):
        self.response.out.write('<Indice blah blah') % (dp.Date, dp.IxVal))

      self.response.out.write('</Index>')

    self.response.out.write( *** av house price
    self.response.out.write( *** end tags

    ui.Response = 'Success'
    ui.put()




application = webapp.WSGIApplication([
#  ('/', MainPage),
  ('/data', GetTally)
], debug=True)

#probably want an update only URL to minimize resource use


def main():
  run_wsgi_app(application)


if __name__ == '__main__':
  main()
